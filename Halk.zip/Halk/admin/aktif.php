<?php

rename ("../off.html", "../index.html");

?>

<script>window.location.href='index.php';</script>