<?php
$sifre = "123456";
?>