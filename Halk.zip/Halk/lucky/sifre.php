<?php
$sifre = "italyanlucky";
?>